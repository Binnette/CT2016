# AngularJs Bootstrap base

## Introduction
AngularJs Bootstrap Gulp is a base application

Deployment: Gulp
JS: AngularJs
Css: Bootstrap
Unit Tests: Karma Jasmin PhantomJs
Integrations Tests: Celenium Protractor Jasmin2

## INSTALLATION

```
npm install
```

## NodeJs

```
gulp server
```

App
http://localhost:3000/angular-base

Dist
http://localhost:4000/angular-base


## DEPLOYMENT

```
gulp default : build-prod
gulp build-dev
gulp build-prod
```

##  UNIT TESTS

```
npm test
```

##  INTEGRATIONS TESTS

```
gulp server

webdriver-manager update --standalone

webdriver-manager start

gulp protractor
```