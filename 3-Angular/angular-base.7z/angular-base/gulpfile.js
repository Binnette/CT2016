/**
 * Fichier de configuration de gulp
 * Gulp est utilisé pour automatiser les tâches de déploiement, tests unitaires et intégrations.
 */

'use strict';

var gulp = require('gulp');
var wrench = require('wrench');
var runSequence = require('run-sequence');

wrench.readdirSyncRecursive('./gulp').filter(function (file) {
    return (/\.(js|coffee)$/i).test(file);
}).map(function (file) {
    require('./gulp/' + file);
});

gulp.task('build-dev', function () {
    runSequence(['lint'], ['clean'], ['minify'], ['copy'], ['copy-config-dev']);
});

gulp.task('build-prod', function () {
    runSequence(['lint'], ['clean'], ['minify'], ['copy'], ['copy-config-prod']);
});

gulp.task('default', ['build-dev']);
