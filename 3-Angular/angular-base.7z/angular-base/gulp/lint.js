
var gulp = require('gulp');
var jshint = require('gulp-jshint');
var jscs = require('gulp-jscs');
var runSequence = require('run-sequence');
var conf = require('./conf');

gulp.task('jshint', function () {
    return gulp.src(conf.params.jshintFiles)
        .pipe(jshint('.jshintrc'))
        .pipe(jshint());
});

gulp.task('jscs', function () {
    return gulp.src(conf.params.jshintFiles)
        .pipe(jscs({configPath: '.jscsrc'}));
});

gulp.task('lint', function () {
    runSequence(['jshint'], ['jscs']);
});
