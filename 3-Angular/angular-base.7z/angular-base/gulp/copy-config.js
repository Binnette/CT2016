
var gulp = require('gulp');
var conf = require('./conf');

gulp.task('copy-config-dev', function () {
    return gulp.src(conf.params.copyConfigDev)
        .pipe(gulp.dest(conf.params.targetDir));
});

gulp.task('copy-config-prod', function () {
    return gulp.src(conf.params.copyConfigProd)
        .pipe(gulp.dest(conf.params.targetDir));
});
