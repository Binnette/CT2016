
var gulp = require('gulp');
var conf = require('./conf');

gulp.task('copy-html', function () {
    return gulp.src(conf.params.copyHtml)
        .pipe(gulp.dest(conf.params.targetDir + '/app'));
});

gulp.task('copy-assets', function () {
    return gulp.src(conf.params.copyAssets)
        .pipe(gulp.dest(conf.params.targetDir + '/assets'));
});

gulp.task('copy-vendor-fonts', function () {
    return gulp.src(conf.params.copyVendorFonts)
        .pipe(gulp.dest(conf.params.targetDir + '/assets/fonts'));
});

gulp.task('copy-languages', function () {
    return gulp
        .src('src/languages/*')
        .pipe(gulp.dest('dist/languages'));
});

gulp.task('copy', ['copy-html', 'copy-assets', 'copy-vendor-fonts', 'copy-languages']);
