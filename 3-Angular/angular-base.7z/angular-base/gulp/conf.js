/**
 *
 */

exports.params = {
    sourceDir: 'src/app',
    targetDir: 'dist',
    indexPage: 'src/index.html',
    cleanFiles: ['dist'],
    jshintFiles: ['app.js', 'src/app/**/*.js', 'e2e-tests/**/*.js', '!src/app/cache/*.js'],
    copyHtml: 'src/app/**/*.html',
    copyAssets: ['src/assets/{images,fonts}/*'],
    copyVendorFonts: ['node_modules/bootstrap/fonts/*', 'node_modules/font-awesome/fonts/*'],
    copyConfigDev: 'src/config.js',
    copyConfigProd: 'environment/prod/config.module.js',
    minifyHtml: ['dist/**/*.html', '!dist/layout/header.tpl.html'],
    minifyJson: ['dist/**/*.json'],
    copyLanguages: ['src/languages/*.json'],
    injectJs: [
        'src/app/app.js',
        'src/app/app.module.js',
        'src/app/app.{constants,config,route,run}.js',
        'src/app/**/*.module.js',
        'src/app/**/*.module.*.js',
        'src/app/**/*.{route,config,service,provider,controller,component,directive,filter}.js',
        '!src/app/**/*.spec.js'
    ]
};
