'use strict';

var express = require('express');
var bodyParser = require('body-parser');

var context = 'angular-base';

// app
var app = module.exports = express();
app.use(bodyParser.json());
app.use('/node_modules', express.static(__dirname + '/node_modules'));
app.use('/angular-common', express.static(__dirname + '/../angular-common'));
app.use('/' + context, express.static(__dirname + '/src'));

var serverApp = app.listen(3000, function () {
    console.log('app listening at http://%s:%s/%s', 'localhost', serverApp.address().port, context);
});

require('./server/index')(app);
require('./server/debug')(app);
require('./server/register')(app);
require('./server/user')(app);

// dist
var dist = module.exports = express();
dist.use(bodyParser.json());
dist.use('/' + context, express.static(__dirname + '/dist'));

var serverDist = dist.listen(4000, function () {
    console.log('app listening at http://%s:%s/%s', 'localhost', serverDist.address().port, context);
});

require('./server/index')(dist);
require('./server/debug')(dist);
require('./server/register')(dist);
require('./server/user')(dist);
