'use strict';

(function () {
    describe('angular-base', function() {
        beforeEach(function() {
            browser.get('http://localhost:3000/angular-base/#!/index.html');
        });

        it('should automatically redirect to /#!/ when location hash/fragment is empty', function() {
            expect(browser.getLocationAbsUrl()).toMatch('/');
        });
    });
})();

(function () {
    describe('angular-base debug', function() {

        beforeEach(function() {
            browser.get('http://localhost:3000/angular-base/#/debug');
        });

        it('should render <h4>Debug</h4> when user navigates to /debug', function() {
            expect( element( by.tagName('h4')).getText() ).toBeDefined();
        });
    });
})();
