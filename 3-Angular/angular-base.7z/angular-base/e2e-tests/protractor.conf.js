'use strict';

exports.config = {
    allScriptsTimeout: 11000,

    specs: [
        'scenarios.js'
    ],

    multiCapabilities: [
        //{'browserName': 'phantomjs'},
        //{'browserName': 'firefox'},
        {'browserName': 'chrome'}
    ],

    framework: 'jasmine2',

    onPrepare: function() {
        var jasmineReporters = require('jasmine-reporters');
        jasmine.getEnv().addReporter(new jasmineReporters.JUnitXmlReporter({
            consolidateAll: true,
            savePath: 'e2e-tests',
            filePrefix: 'xmloutput'
        }));
    },

    jasmineNodeOpts: {
        defaultTimeoutInterval: 30000
    }
};
