'use strict';

function randomTime() {
    var min = 300;
    var max = 2000;

    if (min < 0) {
        return min + Math.random() * (Math.abs(min) + max);
    } else {
        return min + Math.random() * max;
    }
}

module.exports = function(app)
{
    app.get('/api/register/states', function (req, res) {
        setTimeout(function() {
            var states = [
                {id: 1, name: 'Alabama'},
                {id: 2, name: 'Alaska'},
                {id: 3, name: 'Arizona'},
                {id: 4, name: 'Arkansas'},
                {id: 5, name: 'California'}
            ];

            var result = {states: states};
            res.json(result);
        }, randomTime);
    });

    app.get('/api/register/countries', function (req, res) {
        setTimeout(function() {
            var countries = [
                {id: 1, name: 'United States', code: 'US'},
                {id: 2, name: 'France', code: 'FR'},
                {id: 3, name: 'Japan', code: 'JP'},
                {id: 4, name: 'Russia', code: 'RU'},
                {id: 5, name: 'Spain', code: 'SP'}
            ];

            var result = {countries: countries};
            res.json(result);
        }, randomTime);
    });

};