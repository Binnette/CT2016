(function () {

    'use strict';

    angular
        .module('app')
        .run(['$translate', '$rootScope', '$log', mainAppRun]);

    function mainAppRun($translate, $rootScope, $log) {

        var valuesToTranslate = ['locale', 'lang', 'langName', 'dateFormat'];

        for(var index in valuesToTranslate) {
            var valueToTranslate = valuesToTranslate[index];

            $translate(valueToTranslate).then(function (translatedValue) {
                $rootScope[valueToTranslate] = translatedValue;
            });
        }

        $rootScope.restBaseUrl = config.restBaseUrl;
        $rootScope.environment = config.environment;
        $rootScope.version = config.version;
    }

})();
