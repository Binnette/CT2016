(function () {
    'use strict';

    angular
        .module('app.common')
        .factory('CommonService', ['$q', '$rootScope', 'RestService', '$translate', common]);

    function common($q, $rootScope, RestService) {
        var service = {
            getStates: getStates,
            getCountries: getCountries
        };

        return service;

        function getStates() {
            var deferred = $q.defer();

            RestService.sendQuery($rootScope.restBaseUrl + '/register/states', 'GET').query({}, function (data) {
                deferred.resolve(data);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }

        function getCountries() {
            var deferred = $q.defer();

            RestService.sendQuery($rootScope.restBaseUrl + '/register/countries', 'GET').query({}, function (data) {
                deferred.resolve(data);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }
    }

})();