(function (angular) {
    'use strict';

    angular
        .module('app.common', ['ui.router', 'ngResource']);
})(angular);
