(function (angular) {
    'use strict';

    angular
        .module('app.user', ['ui.router', 'ngResource'])
        //.config(['$routeProvider', tableAppConfig]);
        .config(['$stateProvider', userConfig]);

    function userConfig($stateProvider) {
        $stateProvider.state('user', {
            url: '/user',
            templateUrl: 'app/modules/user/user.tpl.html',
            controller: 'UserController',
            controllerAs: 'vm'
        });
    }
})(angular);
