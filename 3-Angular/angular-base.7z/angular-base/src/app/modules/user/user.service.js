(function (angular) {
    'use strict';

    angular
        .module('app.user')
        .factory('UserService', ['$q', '$rootScope', 'RestService', '$translate', user]);

    function user($q, $rootScope, RestService, $translate) {
        var service = {
            getUser: getUser,
            getUsers: getUsers,
            addEditUser: addEditUser,
            deleteUser: deleteUser,
            getResource: getResource,
            getCustomTheme: getCustomTheme,
            init: init,
            filterBy: filterBy,
            getNotSortBy: getNotSortBy
        };

        return service;

        function getUser(id) {
            var deferred = $q.defer();

            if(id) {
                RestService.sendQuery($rootScope.restBaseUrl + '/user/' + id, 'GET').query({}, function (data) {
                    deferred.resolve(data);
                }, function (error) {
                    deferred.reject(error);
                });
            }

            return deferred.promise;
        }

        function getUsers(urlApi) {
            var deferred = $q.defer();

            RestService.sendQuery(urlApi, 'GET').query({}, function (data) {
                deferred.resolve(data);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }

        function addEditUser(model) {
            var deferred = $q.defer();

            RestService.sendQuery($rootScope.restBaseUrl + '/user', 'PUT').query(model, function (data) {
                deferred.resolve(data);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }

        function deleteUser(id) {
            var deferred = $q.defer();

            RestService.sendQuery($rootScope.restBaseUrl + '/user/' + id, 'DELETE').query({}, function (data) {
                deferred.resolve(data);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }

        function init() {
            return {
                'sortBy': 'id',
                'sortOrder': 'asc'
            };
        }

        function getNotSortBy() {
            return ['action'];
        }

        function filterBy() {
            return {
                'login': '',
                'role': '',
                'enabled': ''
            };
        }

        function getCustomTheme() {
            return {
                iconUp: 'fa fa-chevron-circle-up',
                iconDown: 'fa fa-chevron-circle-down',
                loadOnInit: true
            };
        }

        function getResource() {
            return {
                header: [
                    {
                        key: 'id',
                        name: $translate.instant('common.id'),
                        style: {'width': '10%'}
                    },
                    {
                        key: 'login',
                        name: $translate.instant('user.login'),
                        style: {'width': '20%'}
                    },
                    {
                        key: 'role',
                        name: $translate.instant('user.role'),
                        style: {'width': '20%'}
                    },
                    {
                        key: 'enabled',
                        name: $translate.instant('user.enabled'),
                        style: {'width': '10%'}
                    },
                    {
                        key: 'action',
                        name: $translate.instant('common.action'),
                        style: {'width': '10%', 'pointer-events': 'none'}
                    }
                ]
            };
        }

    }
})(angular);
