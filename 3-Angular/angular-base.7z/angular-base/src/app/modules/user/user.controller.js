(function (angular) {
    'use strict';

    angular
        .module('app.user')
        .controller('UserController', ['$q', 'UserService', 'LoggerService', '$rootScope', '$translate', userController]);

    function userController($q, UserService, LoggerService, $rootScope, $translate) {
        var vm = this;

        vm.init = UserService.init();

        vm.resetFilter = function () {
            vm.filterBy = UserService.filterBy();
        };

        vm.resetFilter();

        vm.resource = UserService.getResource();

        vm.notSortBy = UserService.getNotSortBy();

        vm.reloadCallback = function () {};

        vm.customTheme = UserService.getCustomTheme();

        vm.getUsers = function (params, paramsObj) {
            vm.paramsObj = paramsObj;
            vm.params = params;
            vm.urlApi = $rootScope.restBaseUrl + '/user?' + params;

            return UserService.getUsers(vm.urlApi).then(function (response) {
                var deferred = $q.defer();

                if (response.users.rows.length === 0) {
                    LoggerService.warn('User filter', 'Empty result');
                }

                vm.resource.rows = response.users.rows;
                vm.resource.pagination = response.users.pagination;
                vm.resource.sortBy = response.users['sort-by'];
                vm.resource.sortOrder = response.users['sort-order'];

                deferred.resolve(vm.resource);
                return deferred.promise;
            });
        };

        vm.user = {};

        function getUser(id) {
            UserService.getUser(id).then(function (data) {
                vm.user = data.user;
            });
        };

        vm.addEditModal = function (id) {
            getUser(id);
            vm.showAddEditModal = !vm.showAddEditModal;
        };

        vm.detailsModal = function (id) {
            getUser(id);
            vm.showDetailsModal = !vm.showDetailsModal;
        };

        vm.addEditRow = function (model) {
            UserService.addEditUser(model).then(function () {
                LoggerService.info('User register', 'User edited !!!');
                vm.showAddEditModal = !vm.showAddEditModal;
                vm.reloadCallback();
            });
        };

        vm.deleteRow = function (id) {
            UserService.deleteUser(id).then(function () {
                vm.reloadCallback();
            });
        };
    }
})(angular);
