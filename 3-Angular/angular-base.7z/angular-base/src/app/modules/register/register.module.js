(function (angular) {
    'use strict';

    angular
        .module('app.register', ['ui.router', 'ngResource'])
        //.config(['$routeProvider', formAppConfig])
        .config(['$stateProvider', register]);

    function register($stateProvider) {
        $stateProvider.state('register', {
            url: '/register',
            templateUrl: 'app/modules/register/register.tpl.html',
            controller: 'RegisterController',
            controllerAs: 'vm'
        });
    }
})(angular);
