(function (angular) {
    'use strict';

    angular
        .module('app.register')
        .controller('RegisterController', ['CommonService', 'LoggerService', registerController]);

    function registerController(CommonService, LoggerService) {
        var vm = this;

        vm.open = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            vm.opened = true;
        };

        vm.states = [];
        vm.statesReady = false;
        function getStates() {
            CommonService.getStates().then(function (response) {
                vm.statesList = response;
                vm.statesReady = true;
            });
        }

        vm.countriesList = [];
        vm.countryReady = false;
        function getCountries() {
            CommonService.getCountries().then(function (response) {
                vm.countriesList = response;
                vm.countryReady = true;
            });
        }

        vm.submit = function (model) {
            vm.master = angular.copy(model);
            LoggerService.info('Subscription", "Subscription successfull !!!');
        };

        vm.reset = function () {
            vm.master = {};
            vm.model = angular.copy(vm.master);
        };

        getStates();
        getCountries();
        vm.reset();
    }
})(angular);
