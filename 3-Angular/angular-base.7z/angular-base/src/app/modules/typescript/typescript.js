/// <reference path="../../../node_modules/definitely-typed-angular/angular.d.ts"/>
var typescript;
(function (typescript) {
    'use strict';
    angular.module('app.typescript', ['ui.router', 'ngResource']).config(['$stateProvider', configAppConfig]);
    function configAppConfig($stateProvider) {
        $stateProvider.state('typescript', {
            url: '/typescript',
            template: '<typescript></typescript>'
        });
    }
    ;
})(typescript || (typescript = {}));
//# sourceMappingURL=typescript.js.map