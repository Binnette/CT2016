(function (angular) {
    'use strict';

    angular
        .module('app.debug', ['ui.router', 'ngResource'])
        .config(['$stateProvider', debugAppConfig]);

    function debugAppConfig($stateProvider) {
        $stateProvider.state('debug', {
            url: '/debug',
            templateUrl: 'app/modules/debug/debug.tpl.html',
            controller: 'DebugController',
            controllerAs: 'vm'
        });
    }
})(angular);
