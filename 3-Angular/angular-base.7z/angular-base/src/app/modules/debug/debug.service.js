/**
 * Common service Factory
 * @namespace Factories
 */

(function (angular) {
    'use strict';

    angular
        .module('app.debug')
        .factory('DebugService', ['$q', '$rootScope', 'RestService', debug]);

    function debug($q, $rootScope, RestService) {
        var service = {
            getIndex: getIndex,
            getLongLoad: getLongLoad,
            getUnknown: getUnknown,
            getDebugEcho: getDebugEcho,
            getDebugPing: getDebugPing
        };

        return service;

        function getIndex() {
            var deferred = $q.defer();

            RestService.sendQuery($rootScope.restBaseUrl + '/index', 'GET').query({}, function (data) {
                deferred.resolve(data);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }

        function getLongLoad() {
            var deferred = $q.defer();

            RestService.sendQuery($rootScope.restBaseUrl + '/longload', 'GET').query({}, function (data) {
                deferred.resolve(data);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }

        function getUnknown() {
            var deferred = $q.defer();

            RestService.sendQuery($rootScope.restBaseUrl + '/debug/unknown', 'GET').query({}, function (data) {
                deferred.resolve(data);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }

        function getDebugEcho() {
            var deferred = $q.defer();

            RestService.sendQuery($rootScope.restBaseUrl + '/debug/echo', 'GET').query({}, function (data) {
                deferred.resolve(data);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }

        function getDebugPing() {
            var deferred = $q.defer();

            RestService.sendQuery($rootScope.restBaseUrl + '/debug/ping', 'GET').query({}, function (data) {
                deferred.resolve(data);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }
    }
})(angular);
