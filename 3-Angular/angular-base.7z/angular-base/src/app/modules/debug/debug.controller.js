(function (angular) {
    'use strict';

    angular
        .module('app.debug')
        .controller('DebugController', ['DebugService', 'NotificationService', '$translate', 'ExceptionService', debugController]);

    function debugController(DebugService, NotificationService, $translate, ExceptionService) {
        var vm = this;

        vm.getIndex = function () {
            DebugService.getIndex().then(function (response) {
                vm.index = response;
                NotificationService.info('success', $translate.instant('debug.index'), 'Message ' + response.message);
            });
        };

        vm.getLongLoad = function () {
            DebugService.getLongLoad().then(function (response) {
                vm.longload = response;
                NotificationService.info('success', $translate.instant('debug.longLoad'), 'Message ' + response.message);
            });
        };

        vm.getUnknown = function () {
            DebugService.getUnknown().then(function (response) {
                vm.unknown = response;
                NotificationService.info('success', $translate.instant('debug.unknown'), 'Message ' + response.message);
            }, function (failure) {
                ExceptionService.catcher('getUnknown', 'unknown');
                console.log('getUnknown');
            });
        };

        vm.getDebugEcho = function () {
            DebugService.getDebugEcho().then(function (response) {
                vm.echo = response;
                NotificationService.info('success', $translate.instant('debug.echo'), 'Message ' + response.message);
            });
        };

        vm.getDebugPing = function () {
            DebugService.getDebugPing().then(function (response) {
                vm.ping = response;
                NotificationService.info('success', $translate.instant('debug.ping'), 'Message ' + response.message + ' Code ' + response.code);
            });
        };

        //vm.init = function () {
            //vm.getIndex();
        //};
    }
})(angular);
