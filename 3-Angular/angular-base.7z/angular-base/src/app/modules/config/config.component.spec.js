/**
 *
 * Tests unitaires
 *
 */

(function (angular) {
    'use strict';

    ngDescribe({
        name: 'component: app.config',
        modules: ['app.config'],
        inject: ['$componentController', '$rootScope'],
        tests: function (deps) {

            var scope, component;

            beforeEach(function() {
                scope = deps.$rootScope.$new();
                component = deps.$componentController('config', {$scope: scope});
            });

            it('should set the default values of the hero', function() {
                expect(component.value).toBeDefined();
                expect(component.value.title).toEqual('config title');
                expect(component.value.name).toEqual('config name');
            });
        }
    });
})(angular);
