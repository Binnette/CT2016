(function (angular) {
    'use strict';

    angular.module('app.config').component('config', {
        templateUrl: 'modules/config/config.tpl.html',
        controller: [configController],
        bindings: {
            value: '=?'
        }
    });

    function configController() {
        this.value = {
            title: 'config title',
            name: 'config name'
        }
    }
})(angular);
