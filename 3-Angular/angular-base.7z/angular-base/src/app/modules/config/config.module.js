(function (angular) {
    'use strict';

    angular
        .module('app.config', ['ui.router', 'ngResource'])
        .config(['$stateProvider', configAppConfig]);

    function configAppConfig($stateProvider) {
        $stateProvider.state('config', {
            url: '/config',
            template: '<config></config>'
        });
    }
})(angular);
