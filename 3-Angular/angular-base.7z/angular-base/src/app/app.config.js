(function () {

    'use strict';

    angular
        .module('app')
        .config(['$stateProvider', '$urlRouterProvider', '$locationProvider', '$httpProvider', '$compileProvider', 'logEnhancerProvider', mainAppConfig]);

    function mainAppConfig($stateProvider, $urlRouterProvider, $locationProvider, $httpProvider, $compileProvider, logEnhancerProvider) {
        $compileProvider.debugInfoEnabled(config.debugInfoEnabled);

        logEnhancerProvider.prefixPattern = '%s::[%s]>';
        logEnhancerProvider.datetimePattern = 'dddd h:mm:ss a';

        //logLevels : { TRACE: 4, DEBUG: 3, INFO: 2, WARN: 1, ERROR: 0, OFF: -1 };
        logEnhancerProvider.logLevels = {
            '*': config.logLevel
        };

        $locationProvider.hashPrefix('!');
        $httpProvider.interceptors.push('HttpInterceptor');

        $stateProvider.state('index', {
            url: '/',
            templateUrl: 'app/layout/home.tpl.html'
        }).state('home', {
            url: '/home',
            templateUrl: 'app/layout/home.tpl.html'
        });

        $urlRouterProvider.otherwise('/');
    }
})();
