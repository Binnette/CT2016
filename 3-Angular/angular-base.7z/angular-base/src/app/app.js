(function (angular) {

    'use strict';

    angular
        .module('app', [
            'ngAnimate', 'ui.router', 'ui.bootstrap', 'toaster', 'ngTasty', 'angular-confirm', 'angular-logger',
            'common', 'app.translate',
            'app.common', 'app.register', 'app.user', 'app.debug', 'app.config']);

})(angular);
