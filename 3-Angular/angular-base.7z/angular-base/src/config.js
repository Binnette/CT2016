var config = {
    restBaseUrl: 'http://' + window.location.hostname + ':' + window.location.port + '/api',
    environment: 'dev',
    version: '0.0.1-SNAPSHOT',
    debugInfoEnabled: true,
    logLevel: 4
}
