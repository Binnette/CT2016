var config = {
    restBaseUrl: 'http://localhost:8080/api',
    environment: 'prod',
    version: '0.0.1-SNAPSHOT',
    debugInfoEnabled: false,
    logLevel: 0
}
