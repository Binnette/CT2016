# AngularJs Bootstrap common

## Introduction
AngularJs Bootstrap common directives filters controllers

Deployment: Gulp
JS: AngularJs
Css: Bootstrap
Unit Tests: Karma Jasmin PhantomJs

## INSTALLATION

```
npm install
```

## DEPLOYMENT

```
gulp default : build
gulp build
```

##  UNIT TESTS

```
npm test
```
