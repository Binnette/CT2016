(function () {
    'use strict';

    angular
        .module('common')
        .controller('CommonController', ['$scope', commonController]);

    function commonController($scope) {
        $scope.common = 'something';

        $scope.scrollTop = function () {
            $('body,html').animate({scrollTop: 0}, 'slow');
        };
    }
})();
