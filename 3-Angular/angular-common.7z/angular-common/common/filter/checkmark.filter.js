/**
 * Common Filters
 * @namespace Filters
 */

(function () {
    'use strict';

    angular
        .module('common')
        .filter('checkmark', checkmark);

    /**
     * @name checkmark
     * @returns {Function}
     * @memberOf Filters
     */
    function checkmark() {
        return function (input) {
            return input ? '\u2713' : '\u2718';
        };
    }
})();
