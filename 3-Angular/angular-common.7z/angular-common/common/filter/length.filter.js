/**
 * Common Filters
 * @namespace Filters
 */

(function () {
    'use strict';

    angular
        .module('common')
        .filter('length', getLength);

    /**
     * @name getLength
     * @returns {Function}
     * @memberOf Filters
     */
    function getLength() {
        return function (text) {
            return ('' + (text || '')).length;
        };
    }
})();
