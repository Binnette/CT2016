(function () {
    'use strict';

    ngDescribe({
        name: 'DeclarationFilter',
        inject: '$filter',
        modules: ['common'],
        tests: function (deps) {
            it('should return 0 when given null', function () {
                var length = deps.$filter('length');
                expect(length(null)).toEqual(0);
            });

            it('should return the correct value when given a string of chars', function () {
                var length = deps.$filter('length');
                expect(length('abc')).toEqual(3);
            });
        }
    });
})();
