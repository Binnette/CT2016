(function () {
    'use strict';

    ngDescribe({
        name: 'DeclarationDirective',
        modules: 'common',
        element: '<declaration-directive></declaration-directive>',
        tests: function (deps) {
            it('should test declaration content', function () {
                la(check.has(deps, 'element'), 'has compiled element');
                var scope = deps.element.scope();
                scope.bar = 'bar';
                scope.$apply();
                //la(deps.element.html() === 'Declaration, 2 fois');
                expect(deps.element.html()).toContain('Declaration, 2 fois');
            });
        }
    });
})();
