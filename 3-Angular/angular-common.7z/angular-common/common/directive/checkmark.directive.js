/**
 * Common Directives
 * @namespace Directives
 */

(function () {
    'use strict';

    angular
        .module('common')
        .directive('checkmark', checkmark);

    /**
     * @name checkmark
     * @returns {{scope: {checked: string}, template: string, link: Function}}
     * @memberOf Directives
     */
    function checkmark() {
        return {
            scope: {
                checked: '='
            },
            template: '<i class="{{ cssClass }}"></i>',
            link: function (scope, iElm, iAttrs, controller) {
                if (scope.checked) {
                    scope.cssClass = 'glyphicon glyphicon-ok text-success';
                } else {
                    scope.cssClass = 'glyphicon glyphicon-remove text-danger';
                }
            }
        };
    }
})();
