/**
 * Common Directives
 * @namespace Directives
 */

(function () {
    'use strict';

    angular
        .module('common')
        .directive('loader', loader);

    /**
     * @name loader
     * @returns {{scope: {loading: string}, template: string, link: Function}}
     * @memberOf Directives
     */
    function loader() {
        return {
            scope: {
                loading: '='
            },
            template: '<i ng-show="loading" title="loading" class="fa fa-spinner fa-pulse"></i>',
            link: function (scope, iElm, iAttrs, controller) {

            }
        };
    }
})();
