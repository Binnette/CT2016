/**
 * Common Directives
 * @namespace Directives
 */

(function () {
    'use strict';

    angular
        .module('common')
        .directive('affixTop', ['$window', affixTop]);

    /**
     * @name affixTop
     * @param $window
     * @returns {{restrict: string, link: Function}}
     * @memberOf Directives
     */
    function affixTop($window) {
        var applyAffix = function (element) {
            var clientRect = document.body.getBoundingClientRect();

            if ($(window).scrollTop() > 100) {
                element.removeClass('affix-top').addClass('affix');
            } else {
                element.removeClass('affix').addClass('affix-top');
            }
        };

        return {
            restrict: 'A',
            link: function (scope, element) {
                angular.element($window).on('scroll', function () {
                    applyAffix(element);
                });
                applyAffix(element);
            }
        };
    }
})();
