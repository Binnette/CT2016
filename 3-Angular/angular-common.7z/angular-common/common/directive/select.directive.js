/**
 * Common Directives
 * @namespace Directives
 */

(function () {
    'use strict';

    angular
        .module('common')
        .directive('selectWatcher', ['$timeout', selectWatcher])
        .directive('selectPicker', selectPicker);

    /**
     *
     * @param $timeout
     * @returns {{link: Function}}
     * @memberOf Directives
     */
    function selectWatcher($timeout) {
        return {
            link: function (scope, element, attr) {
                var last = attr.last;
                if (last) {
                    $timeout(function () {
                        $(element).parent().selectpicker('refresh');
                    });
                }
            }
        };
    }

    /**
     *
     * @returns {{restrict: string, link: Function}}
     * @memberOf Directives
     */
    function selectPicker() {
        return {
            restrict: 'C',
            link: function (scope, element, attr) {
                $(element).selectpicker({
                    style: 'btn-default',
                    size: false
                });
            }
        };
    }
})();
