/**
 * Common Directives
 * @namespace Directives
 */

(function () {
    'use strict';

    angular
        .module('common')
        .directive('scrollTop', scrollTop);

    /**
     * @name scrollTop
     * @returns {{scope: {}, template: string, link: Function}}
     * @memberOf Directives
     */
    function scrollTop() {
        return {
            scope: {},
            template: '<a class="scroll-top affix" title="Scroll to the top" ng-click="scrollTop()" affix-top><i class="fa fa-angle-double-up fa-2x fa-border"></a>',
            link: function (scope, iElm, iAttrs, controller) {
                scope.scrollTop = function () {
                    $('body,html').animate({scrollTop: 0}, 'slow');
                };
            }
        };
    }
})();
