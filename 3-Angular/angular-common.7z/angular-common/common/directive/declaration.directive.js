/**
 * Common Directives
 * @namespace Directives
 */

(function () {
    'use strict';

    angular
        .module('common')
        .directive('declarationDirective', declarationDirective);

    /**
     *
     * @returns {{restrict: string, replace: boolean, template: string}}
     * @memberOf Directives
     */
    function declarationDirective() {
        return {
            restrict: 'E',
            replace: true,
            template: '<h2>Declaration, {{ 1 + 1 }} fois</h2>'
        };
    }
})();
