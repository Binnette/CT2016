/**
 * Common Directives
 * @namespace Directives
 */

(function () {
    'use strict';

    angular
        .module('common')
        .directive('customDatePicker', ['$translate', customDatePicker]);

    var datepickertpl = '<div class="input-group"> ' +
    '<input ' +
    'type="text" ' +
    'class="{{ customclass }}" ' +
    'datepicker-popup="{{ dateformat }}" ' +
    'ng-model="model" ' +
    'is-open="opened" ' +
    'min-date="minDate" ' +
    'datepicker-options="dateOptions" ' +
    'date-disabled="disabled(date, mode)" ' +
    'ng-required="true" ' +
    'close-text="Close" ' +
    'name="birthDate" ' +
    'id="{{ customid }} "/> ' +
    '<span class="input-group-addon" id="basic-addon2"> ' +
    '<button type="button" ng-click="open($event)"><i class="glyphicon glyphicon-calendar"></i></button> ' +
    '</span> ' +
    '</div>';

    /**
     * @name customDatePicker
     * @desc customDatePicker directive
     * @param Config
     * @param $translate
     * @returns {{templateUrl: string, scope: {model: string, dateformat: string, customclass: string, customid: string}, link: Function, restrict: string}}
     * @memberOf Directives
     */
    function customDatePicker($translate) {
        return {
            template: datepickertpl,
            scope: {
                model: '=',
                dateformat: '@?',
                customclass: '@?',
                customid: '@?'
            },
            link: function link(scope, element, attrs) {
                if (!scope.dateformat) {
                    scope.dateformat = $translate.instant('dateFormat');
                }

                if (!scope.customclass) {
                    scope.customclass = 'form-control';
                }

                scope.opened = false;

                scope.open = function ($event) {
                    $event.preventDefault();
                    $event.stopPropagation();

                    if (scope.opened) {
                        scope.opened = false;
                    } else {
                        scope.opened = true;
                    }
                };
            },
            restrict: 'E'
        };
    }
})();
