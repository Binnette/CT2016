/**
 * Common Directives
 * @namespace Directives
 */

(function () {
    'use strict';

    angular
        .module('common')
        .directive('back', ['$window', back]);

    /**
     * @name back
     * @desc back directive
     * @param $window
     * @returns {{restrict: string, link: Function}}
     * @memberOf Directives
     */
    function back($window) {
        return {
            restrict: 'A',
            link: function (scope, elem, attrs) {
                elem.bind('click', function () {
                    $window.history.back();
                });
            }
        };
    }
})();
