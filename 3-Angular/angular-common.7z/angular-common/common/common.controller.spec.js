(function () {
    'use strict';

    ngDescribe({
        name: 'CommonController',
        modules: 'common',
        inject: ['$timeout'],
        controllers: 'CommonController',
        tests: function (deps) {
            it('should test $scope.common is "something"', function () {
                expect(deps.CommonController.common).toEqual('something');
            });
        }
    });
})();
