/**
 * Common service Factory
 * @namespace Factories
 */

(function () {
    'use strict';

    angular
        .module('common')
        .factory('NotificationService', ['toaster', notificationService]);

    /**
     *@name LoggerService
     * @param toaster
     * @returns {{info: info, warn: warn, error: error}}
     * @memberOf Factories
     */
    function notificationService(toaster) {
        var service = {
            info: info,
            warn: warn,
            error: error
        };

        return service;

        function info(title, message) {
            toaster.pop('success', title, message);
        }

        function warn(title, message) {
            toaster.pop('warning', title, message);
        }

        function error(title, message) {
            toaster.pop('error', title, message);
        }
    }
})();
