
(function () {
    'use strict';

    angular
        .module('common')
        .provider('$language', ['$windowProvider', lang]);

    function lang($windowProvider) {
        this.$get = function(langs) {
            var language = $windowProvider.$get().navigator.userLanguage || $windowProvider.$get().navigator.language;

            for(var index in langs) {
                var lang = langs[index];

                if (language && language.indexOf(lang) != -1) {
                    return lang;
                }
            }

            return 'en';
        }
    }
})();
