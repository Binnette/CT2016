(function () {
    'use strict';

    ngDescribe({
        name: 'RestService',
        modules: 'common',
        inject: ['$httpBackend', 'RestService'],
        tests: function (deps) {
            it('should CommonRestService factory defined', function () {
                expect(deps.RestService).toBeDefined();
            });

            it('should http query /api/debug/ping should return message', function() {
                var content = {code:200,message:'OK'};
                var result = {};

                deps.$httpBackend.whenGET('/api/debug/ping').respond(content);

                deps.RestService.sendQuery('/api/debug/ping', 'GET').query({}).$promise.then(function(response) {
                    result = response;
                });

                expect(result.message).not.toEqual(content.message);
                deps.$httpBackend.flush();
                expect(result.message).toEqual(content.message);
            });
        }
    });
})();
