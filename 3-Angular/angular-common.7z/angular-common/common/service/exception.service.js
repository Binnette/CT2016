/**
* Common service Factory
* @namespace Factories
*/

(function () {
    'use strict';

    angular
        .module('common')
        .factory('ExceptionService', ['LoggerService', exception]);

    /**
     * @name exception
     * @desc exception logger
     * @returns {{catcher: catcher}}
     * @memberOf Factories
     */
    function exception(LoggerService) {
        var service = {
            catcher: catcher
        };
        return service;

        function catcher(message, reason) {
            LoggerService.error('Exception : ' + message + ' ' + reason);
        }
    }
})();
