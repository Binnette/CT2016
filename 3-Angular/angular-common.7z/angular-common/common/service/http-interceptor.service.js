/**
 * Common service Factory
 * @namespace Factories
 */

(function () {
    'use strict';

    angular
        .module('common')
        .factory('HttpInterceptor', ['$q', '$rootScope', '$location', 'NotificationService', '$cacheFactory', httpInterceptor]);

    /**
     * @name HttpInterceptor
     * @param $q
     * @param $rootScope
     * @param $location
     * @param LoggerService
     * @param $translate
     * @returns {{request: Function, requestError: Function, response: Function, responseError: Function}}
     * @memberOf Factories
     */
    function httpInterceptor($q, $rootScope, $location, NotificationService, $cacheFactory) {
        return {
            request: function (config) {
                $rootScope.loading = true;
                return config || $q.when(config);
            },
            requestError: function (request) {
                NotificationService.error('http request', 'http request error');
                $rootScope.loading = false;
                return $q.reject(request);
            },
            response: function (response) {
                //NotificationService.info('http request', 'http request error');
                $rootScope.loading = false;

                $cacheFactory.get('$http').removeAll()

                return response || $q.when(response);
            },
            responseError: function (response) {

                $rootScope.loading = false;

                if (response && response.status >= 300) {
                    NotificationService.error('Network error', 'HTTP ' + response.status);
                }

                return $q.reject(response);
            }
        };
    }
})();
