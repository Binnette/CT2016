/**
 * Common service Factory
 * @namespace Factories
 */

(function () {
    'use strict';

    angular
        .module('common')
        .factory('LoggerService', [loggerService]);

    /**
     *@name LoggerService
     * @returns {{info: info, warn: warn, error: error}}
     * @memberOf Factories
     */
    function loggerService() {
        var service = {
            info: info,
            warn: warn,
            error: error
        };

        return service;

        function info(message) {
            console.log(message);
        }

        function warn(message) {
            console.warn(message);
        }

        function error(message) {
            console.error(message);
        }
    }
})();
