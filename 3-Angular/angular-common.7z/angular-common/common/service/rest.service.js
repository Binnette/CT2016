/**
 * Common service Factory
 * @namespace Factories
 */

(function () {
    'use strict';

    angular
        .module('common')
        .factory('RestService', ['$resource', restService]);

    function restService($resource) {
        var service = {
            sendQuery: sendQuery
        };

        return service;

        function sendQuery(url, method) {
            return $resource(url, {}, {
                query: {
                    method: method,
                    cache: true,
                    headers: {
                        'Accept': 'application/json'
                    },
                    params: {},
                    isArray: false
                }
            });
        }
    }
})();
