/**
 * Gulp config
 */

'use strict';

var gulp = require('gulp');
var concat = require('gulp-concat');
var minify = require('gulp-minify');
var runSequence = require('run-sequence');
var del = require('del');
var uglify = require('gulp-uglify');
var concatCss = require('gulp-concat-css');
var minifyCss = require('gulp-minify-css');
var rename = require('gulp-rename');
var sourcemaps = require('gulp-sourcemaps');

gulp.task('karma', function (done) {
    karma.start({
        configFile: __dirname + '/karma.conf.js',
        singleRun: true
    }, done);
});

gulp.task('clean', function () {
    return del(['dist']);
});

gulp.task('concat-common', function() {
    return gulp.src(['common/common.module.js', 'common/common.controller.js', 'common/**/*.js', '!common/**/*.spec.js'])
        .pipe(concat('common.js'))
        .pipe(gulp.dest('dist'));
});

gulp.task('concat-translate', function() {
    return gulp.src(['translate/translate.module.js', 'translate/translate.controller.js', '!translate/**/*.spec.js'])
        .pipe(concat('translate.js'))
        .pipe(gulp.dest('dist'));
});

gulp.task('minify', function() {
    gulp.src(['dist/common.module.js', 'dist/translate.module.js'])
        .pipe(minify())
        .pipe(gulp.dest('dist'))
});

gulp.task('uglify', function() {
    return gulp.src(['dist/common-min.js', 'dist/translate-min.js'])
        .pipe(uglify())
        .pipe(gulp.dest('dist'));
});

gulp.task('concat-css', function () {
    return gulp.src('css/*.css')
        .pipe(concatCss('common.css'))
        .pipe(gulp.dest('dist'));
});

gulp.task('minify-css', function() {
    return gulp.src('dist/common.css')
        .pipe(minifyCss({compatibility: 'ie8'}))
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('dist'));
});

gulp.task('process-js', function() {
    gulp.src([
        'common/common.module.js', 'common/**/*.js', '!common/**/*.spec.js'
    ])
        .pipe(sourcemaps.init())
        .pipe(concat('common.js'))
        .pipe(uglify({
            compress: {
                negate_iife: false
            }
        }))
        .pipe(rename('common.min.js'))
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest('dist'));
});

gulp.task('build', runSequence(
    ['clean'],
    ['concat-css'],
    ['minify-css'],
    ['process-js']
));

gulp.task('default', ['build']);