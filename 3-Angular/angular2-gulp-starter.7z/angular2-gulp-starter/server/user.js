'use strict';

var query = require('array-query');

var roleData = [
    'ROLE_ADMIN', 'ROLE_USER', 'ROLE_OPERATOR', 'ROLE_GUEST'
];

var usersDatas = [
    {id: 1, login: 'admin', role: 'ROLE_ADMIN', enabled: true},
    {id: 2, login: 'user', role: 'ROLE_USER', enabled: true},
    {id: 3, login: 'operator', role: 'ROLE_OPERATOR', enabled: true},
    {id: 4, login: 'printer', role: 'ROLE_USER', enabled: true},
    {id: 5, login: 'trainy', role: 'ROLE_USER', enabled: true},
    {id: 6, login: 'user2', role: 'ROLE_USER', enabled: true},
    {id: 7, login: 'master', role: 'ROLE_USER', enabled: true},
    {id: 8, login: 'trainy2', role: 'ROLE_USER', enabled: true},
    {id: 9, login: 'user', role: 'ROLE_USER', enabled: true},
    {id: 10, login: 'guest', role: 'ROLE_GUEST', enabled: true},
    {id: 11, login: 'anonymous', role: 'ROLE_GUEST', enabled: true},
    {id: 12, login: 'user', role: 'ROLE_USER', enabled: true},
    {id: 13, login: 'user', role: 'ROLE_USER', enabled: true},
    {id: 14, login: 'user', role: 'ROLE_USER', enabled: false},
    {id: 15, login: 'user', role: 'ROLE_USER', enabled: false},
    {id: 16, login: 'user', role: 'ROLE_USER', enabled: false}
];

function randomTime() {
    var min = 300;
    var max = 2000;

    if (min < 0) {
        return min + Math.random() * (Math.abs(min) + max);
    } else {
        return min + Math.random() * max;
    }
}

module.exports = function (app) {
    app.get('/api/user/role', function (req, res) {
        setTimeout(function() {
            res.json({roles: roleData});
        }, randomTime);
    });

    app.delete('/api/user/:id', function (req, res) {
        var id = parseInt(req.params.id);

        for (var i = 0; i < usersDatas.length; i++) {
            var user = usersDatas[i];
            if (user && user.id === id) {
                usersDatas.splice(i, 1);
            }
        }

        res.json({result: 'ok ' + id});
    });

    app.put('/api/user', function (req, res) {
        var user = req.body;

        if (!user.id) {
            user.id = (usersDatas.length + 1);
            usersDatas.push(user);
        } else {
            for (var i = 0; i < usersDatas.length; i++) {
                var userToDelete = usersDatas[i];
                if (userToDelete && userToDelete.id === user.id) {
                    usersDatas[i] = user;
                    break;
                }
            }
        }

        res.json({result: user});
    });

    app.get('/api/user/:id', function (req, res) {
        var id = parseInt(req.params.id);

        for (var i = 0; i < usersDatas.length; i++) {
            var user = usersDatas[i];

            if (user && user.id == id) {
                break;
            }
        }

        res.json({user: user});
    });

    app.get('/api/user', function (req, res) {

        var page = parseInt(req.query.page);
        var count = parseInt(req.query.count);
        var offset = parseInt(((page - 1) * count));

        var sortBy = req.query['sort-by'];
        var sortOrder = req.query['sort-order'];

        var filterLogin = req.query.login;
        var filterRole = req.query.role;
        var filterEnabled = req.query.enabled;

        setTimeout(function () {

            var rows = [];
            var rowQuery;

            if (filterEnabled) {
                if (filterEnabled === 'true') {
                    rowQuery = query('enabled').is(true);
                } else {
                    rowQuery = query('enabled').is(false);
                }
            } else if (filterLogin) {
                rowQuery = query('login').startsWith(filterLogin);
            } else if (filterRole) {
                rowQuery = query('role').startsWith(filterRole);
            } else {
                rowQuery = query();
            }

            var filteredDatas = rowQuery.on(usersDatas);

            rowQuery.limit(count).offset(offset);

            rowQuery.sort(sortBy).asc();

            if (sortOrder) {
                if (sortOrder === 'asc') {
                    rowQuery.asc();
                }

                if (sortOrder === 'dsc') {
                    rowQuery.desc();
                }
            }

            rows = rowQuery.on(filteredDatas);

            var pagination = {
                size: filteredDatas.length
            };

            var result = {
                rows: rows,
                pagination: pagination
            };

            res.json({"users": result});
        }, randomTime);
    });
};