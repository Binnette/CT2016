'use strict';

var express = require('express');
var bodyParser = require('body-parser');
var cors = require('express-cors');

// app
var app = module.exports = express();
app.use(cors({
    allowedOrigins: [
        '*'
    ]
}))
app.use(bodyParser.json());

var serverApp = app.listen(5000, function () {
    console.log('app listening at http://%s:%s', 'localhost', serverApp.address().port);
});

require(__dirname + '/index')(app);
require(__dirname + '/debug')(app);
require(__dirname + '/register')(app);
require(__dirname + '/user')(app);
