import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';

import { APP_PROVIDERS } from './app.providers';
import { AppComponent } from './app.component';
import { appRoutingProviders, routing } from './app.routing';
import { NavbarModule } from './common';
import { SpinnerModule } from './common';

import { HomeModule } from './home/home.module';
import { TodolistModule } from './todolist/todolist.module';
import { TestModule } from './test/test.module';
import { DebugModule } from './debug/debug.module';
import { BootstrapSharedModule, TranslateSharedModule } from './common/shared/index';

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        routing,
        HttpModule,
        FormsModule,
        BrowserModule,
        BootstrapSharedModule, TranslateSharedModule,
        NavbarModule,
        SpinnerModule,
        HomeModule,
        TodolistModule,
        TestModule,
        DebugModule
    ],
    providers: [ APP_PROVIDERS, appRoutingProviders ],
    bootstrap: [ AppComponent ]
})

export class AppModule {
}
