import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/toPromise';

export class Status {
    code: number;
    name: string;
}

@Injectable()
export class DebugService {

    private url = 'assets/json/status.json';

    constructor(private _http: Http) { }

    private status: Status = {
        code: 0,
        name: 'test'
    };

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }

    private extractData(res: Response) {
        return res.json() || null;
    }

    public getTest(): String {
        return 'test';
    }

    public getHttpStatus(): Promise<Status> {
        /*return this._http.get(this.url)
            .toPromise()
            .then(this.extractData)
            .catch(this.handleError);*/

        return this._http.get(this.url)
            .toPromise()
            .then((response: Response) => response.json() || null as Status)
            .catch((error: any): Promise<any> => Promise.reject(error.message || error));
    }

    public getStatus(): Status {
        return this.status;
    };

    public getStatusPromise(): Promise<Status> {
        return Promise.resolve(this.status);
    }

    public getStatusPromiseSlowly(): Promise<Status> {
        return new Promise<Status>(resolve =>
            setTimeout(resolve, 2000))
            .then(() => this.getStatus());
    }
}
