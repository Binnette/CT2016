import { NgModule } from '@angular/core';
import { DebugComponent } from './index';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

@NgModule({
    declarations: [
        DebugComponent
    ],
    exports: [
        DebugComponent
    ],
    imports: [
        FormsModule,
        BrowserModule
    ]
})
export class DebugModule {}
