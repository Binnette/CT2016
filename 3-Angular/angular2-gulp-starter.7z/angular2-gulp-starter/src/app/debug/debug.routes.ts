import { Routes } from '@angular/router';

import { DebugComponent } from './debug.component';

export const DebugRoutes: Routes = [
    { path: 'debug',  component: DebugComponent }
];
