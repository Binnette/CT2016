import { Component, OnInit } from '@angular/core';
import { DebugService, Status } from './debug.service';
import { CONSTANTS } from '../common';

@Component({
    selector: 'as-debug',
    providers: [ DebugService ],
    templateUrl: 'app/debug/debug.html',
    styleUrls: [
        'app/debug/debug.css'
    ]
})

export class DebugComponent implements OnInit {

    private baseUrl: String;
    private status: Status;
    private statusPromise: Status;
    private statusPromiseHttp: Status;
    private statusPromiseSlowly: Status;

    constructor(private _debugService: DebugService) {
        this.baseUrl = CONSTANTS.MAIN.REST.BASE_URL;
    }

    public getTest(): String {
        return this._debugService.getTest();
    }

    public getStatus(): void {
        this.status = this._debugService.getStatus();

        console.log('status : ' + JSON.stringify(this.status));
    }

    public getHttpStatus(): void {
        this._debugService.getHttpStatus().then(status => {
            this.statusPromiseHttp = status;
            console.log('statusPromiseHttp : ' + JSON.stringify(this.statusPromiseHttp));
        }).catch(error => {
            console.log('error : ' + error.stack);
        });
    }

    public getStatusPromise(): void {
        this._debugService.getStatusPromise().then(status => {
            this.statusPromise = status;
            console.log('statusPromise : ' + JSON.stringify(this.statusPromise));
        }).catch(error => {
            console.log('error : ' + error.stack);
        });
    }

    public getStatusPromiseSlowly(): void {
        this._debugService
            .getStatusPromiseSlowly()
            .then((status:Status) => this.statusPromiseSlowly = status);
    }

    ngOnInit(): void {
        this.getTest();
        this.getStatus();
        this.getStatusPromise();
        this.getHttpStatus();
        this.getStatusPromiseSlowly();
    }
}
