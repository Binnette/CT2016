export * from './debug.component';
export * from './debug.routes';
export * from './debug.module';
