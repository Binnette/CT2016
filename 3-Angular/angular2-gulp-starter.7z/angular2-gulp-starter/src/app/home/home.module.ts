import { NgModule } from '@angular/core';
import { HomeComponent } from './index';
import { BootstrapSharedModule, TranslateSharedModule } from '../common/shared/index';

@NgModule({
    declarations: [
        HomeComponent
    ],
    exports: [
        HomeComponent
    ],
    imports: [ BootstrapSharedModule, TranslateSharedModule ]
})

export class HomeModule {

}
