import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { TranslateService } from 'ng2-translate/ng2-translate';


@Component({
    selector: 'as-custom-navbar',
    templateUrl: 'app/common/navbar/navbar.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})

export class NavbarComponent {
    @Input() brand: string;

    private _translateService: TranslateService;

    constructor(translateService: TranslateService) {
        this._translateService = translateService;
        this._translateService.setDefaultLang('en');
        this._translateService.use(this._translateService.getBrowserLang());
    }

    public setLanguage(language:string):void {
        this._translateService.use(language);
    }

    public getAviableLanguages():string[] {
        return ['en', 'fr'];
    }
}
