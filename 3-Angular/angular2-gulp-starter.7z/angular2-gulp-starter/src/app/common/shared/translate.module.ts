import { NgModule } from '@angular/core';
import { HttpModule, Http } from '@angular/http';
import { TranslateModule, TranslateLoader, TranslateStaticLoader, TranslateService } from 'ng2-translate/ng2-translate';

@NgModule({
    declarations: [

    ],
    exports: [ TranslateModule, HttpModule ],
    imports: [
        HttpModule,
        TranslateModule.forRoot({
            provide: TranslateLoader,
            useFactory: (http: Http) => new TranslateStaticLoader(http, '/assets/i18n', '.json'),
            deps: [Http]
        })
    ]
})

export class TranslateSharedModule {
    param: string = "world";
    /*private _translateService: TranslateService;

    constructor(_translateService: TranslateService) {
        _translateService.setDefaultLang('en');
        _translateService.use(_translateService.getBrowserLang());
    }

    public setLanguage(language:string):void {
        this._translateService.use(language);
    }

    public getAviableLanguages():string[] {
        return this._translateService.getLangs();
    }*/
}