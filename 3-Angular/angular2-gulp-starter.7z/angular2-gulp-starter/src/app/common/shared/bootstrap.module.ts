import { NgModule } from '@angular/core';
import { Ng2BootstrapModule } from 'ng2-bootstrap/ng2-bootstrap';

@NgModule({
    exports: [ Ng2BootstrapModule  ],
    imports: [
        Ng2BootstrapModule
    ]
})

export class BootstrapSharedModule {

}