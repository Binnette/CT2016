import { NgModule } from '@angular/core';
import { SpinnerComponent } from './index';
import { BrowserModule } from '@angular/platform-browser';

@NgModule({
    declarations: [
        SpinnerComponent
    ],
    exports: [
        SpinnerComponent
    ],
    imports: [
        BrowserModule
    ]
})

export class SpinnerModule {
}
