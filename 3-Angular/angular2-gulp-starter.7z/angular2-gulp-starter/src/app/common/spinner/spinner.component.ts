import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'as-spinner',
    templateUrl: 'app/common/spinner/spinner.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})

export class SpinnerComponent {
    @Input() cssClass: String = 'center-fix main-spinner fa fa-spin fa-spinner';
}
