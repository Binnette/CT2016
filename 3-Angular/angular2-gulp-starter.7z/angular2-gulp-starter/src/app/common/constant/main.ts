export const MAIN = {
    APP: {
        BRAND: 'Angular 2 Starter'
    },
    REST: {
        BASE_URL: 'http://localhost:5000/api'
    }
};
