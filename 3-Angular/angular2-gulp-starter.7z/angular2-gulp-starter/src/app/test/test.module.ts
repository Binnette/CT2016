import { NgModule } from '@angular/core';
import { TestComponent } from './index';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { BootstrapSharedModule, TranslateSharedModule } from '../common/shared/index';


@NgModule({
    declarations: [
        TestComponent
    ],
    exports: [
        TestComponent
    ],
    imports: [
        FormsModule,
        BrowserModule,
        BootstrapSharedModule, TranslateSharedModule
    ]
})

export class TestModule {

}
