import { Component } from '@angular/core';

@Component({
    selector: 'as-test',
    templateUrl: 'app/test/test.html',
    styleUrls: [
        'app/test/test.css'
    ]
})
export class TestComponent {
    date: Date = new Date();
}
